﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;		//to reload scene when player dies

public class Enemy2 : MonoBehaviour {

	private Vector3 init_position;	//initial position
	public float speedx = 4;		//individual horizontal enemy speed
	public float speedy = 3;		//individual vertical enemy speed
	Transform movement;		//manipulate position

	// Use this for initialization
	void Start () {

		movement = GetComponent<Transform>();	//retreive object position

		init_position = movement.position;		//initial position is set

	}

	// Update is called once per frame
	void Update() {

		//change initial position using mathf.pingpong()
		movement.position = new Vector3(init_position.x + speedx*Mathf.PingPong(Time.time, speedx), init_position.y + Mathf.PingPong(Time.time, speedy), init_position.z);
		//x and y movements manipulated for enemy2 flying characters

	}

	//function when enemy object collides with player object
	void OnTriggerEnter(Collider other)
	{
		//if enemy box collider contacts player, destroys player
		//removes player
		//when player is destroyed, loads scene again
		if (other.gameObject.tag == "Player") {
			Debug.Log ("collided with player");
			Destroy (other.gameObject);
			SceneManager.LoadScene ("Trial");
		}
	}

}