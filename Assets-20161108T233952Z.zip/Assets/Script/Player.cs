﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

    private float inputDirection;               //X value of moveVector
    private float verticalVelocity;             //Y value of moveVector
	private bool isRunning = false;						//is player running

    public float gravity = 25.0f;               //constantly subtracting y axis, unless on ground
    public float speed = 5.5f;                 //speed of the player
	public float jumpForce = 12.0f;			//height of the jump
	private float currentheight = 0.0f;
	private float previousheight = 0.0f;
	private float travel = 0.0f;

	private CharacterController controller;     //collision for player
    private Vector3 moveVector;                 //representation of 3d vectors for player
	private Vector3 lastMotion;					//maybe useful for future implementations

	//private bool wallJump = false;				//limits one wall jump, resets when player lands
	private bool isFalling = false;
	private bool onWall = false;
	// Use this for initialization
	void Start () {
        controller = GetComponent<CharacterController>();
	}
		

    // Update is called once per frame
    void Update() {
		moveVector = Vector3.zero;
		//Left Right Movement
		inputDirection = Input.GetAxis ("Horizontal") * speed;

		currentheight = transform.position.y;
		travel = currentheight - previousheight;
		if (travel < 0)
			isFalling = true;
		else
			isFalling = false;
		previousheight = currentheight;
		/* here it checks if player is on ground, and resets wall jump is true. It also 
		 * ensures player falls based on the variable gravity by minusing the verticalVelocity,
		 * which is the Y movement for the player. */

		if (isPlayerGrounded() == true)
        {
			onWall = false;
			gravity = 25.0f;
            verticalVelocity = 0;
	
			if (Input.GetKey (KeyCode.V)) {
				speed = 11.5f;
				isRunning = true;
			} else {
				speed = 5.5f;
				isRunning = false;
			}

			//if (wallJump == true)
			//	wallJump = false;
			if (Input.GetKeyDown(KeyCode.Space))
            {
				//Debug.Log ("key being pressed");
                //make player jump
                verticalVelocity = jumpForce;
            }
        }
        else
        {
			if (onWall == true) {
				moveVector.x = lastMotion.x;
			}
			verticalVelocity -= gravity*Time.deltaTime;
        }
		if (onWall == false) {
			moveVector.x = inputDirection;
		}
		moveVector.y = verticalVelocity; 
        controller.Move(moveVector * Time.deltaTime);
		lastMotion = moveVector;

		if (controller.collisionFlags != CollisionFlags.Sides && isPlayerGrounded () == false) {
			gravity = 25.0f;
		}

    }

	/* here we use the library function OnControllerColliderHit, which is called everytime player
	 * collides on a surface, in order to signal if the player is touching wall on one of its sides.
	 * This will also check to see if player presses up arrow to wall jump and if it is its first time
	 * doing so. bool variable wallJump limits the player to one wall jump */

	private void OnControllerColliderHit(ControllerColliderHit hit){
		if (controller.collisionFlags == CollisionFlags.Sides && isPlayerGrounded () == false) {
			onWall = false;
			if (Input.GetKeyDown (KeyCode.Space)) {
				onWall = true;
				moveVector = hit.normal * speed; 
				verticalVelocity = jumpForce;
			}
			if (isFalling == true) {
				//needs something to stop veritcal velocity in motion
				gravity = 3.0f;

			} else {
				gravity = 25.0f;
			}
		}
	}


	/* Checks to see if player is on the ground or not */

	bool isPlayerGrounded(){
		Vector3 leftRayStart;
		Vector3 rightRayStart;
		RaycastHit hitInfo;

		leftRayStart = controller.bounds.center;
		rightRayStart = controller.bounds.center;

		leftRayStart.x -= controller.bounds.extents.x;
		rightRayStart.x += controller.bounds.extents.x;

		Debug.DrawRay(leftRayStart, Vector3.down, Color.cyan);
		Debug.DrawRay(rightRayStart, Vector3.down, Color.green);

		if (Physics.Raycast (rightRayStart, Vector3.down, out hitInfo, (controller.height / 2.0f) + 0.1f)) {
			if (hitInfo.collider.gameObject.tag != "Player")
				return true;
		}
		if (Physics.Raycast (leftRayStart, Vector3.down, out hitInfo, (controller.height / 2.0f) + 0.1f)) {
			if (hitInfo.collider.gameObject.tag != "Player")
				return true;
		}
		return false;
	}
		
}
